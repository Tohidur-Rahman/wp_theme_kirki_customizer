=== Kirki Tab Control ===

Contributors: davidvongries
Tags: kirki-tabs-module
Requires at least: 5.2
Tested up to: 5.9
Requires PHP: 7.0
License: GPL-3.0 License
License URI: https://oss.ninja/gpl-3.0?organization=Kirki%20Framework&project=kirki%20pro%20tabs

== Description ==
Tab extension for Kirki Customizer Framework.
